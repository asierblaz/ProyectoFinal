<?php 

header ("Location: layout.html"); 
 ?>