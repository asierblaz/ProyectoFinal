<?php
$local=1; //0 para la aplicación en 000WebHost
if ($local==1){
$servidor="localhost";
$usuario="root";
$password="";
$basededatos="proyecto";

}
else{
    
    $servidor = "localhost";
    $usuario = "id7284360_usuario";
    $password = "QQ22qq22";
    $basededatos ="id7284360_opcional";

}
?>